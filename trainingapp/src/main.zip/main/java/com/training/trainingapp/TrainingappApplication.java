package com.training.trainingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingappApplication.class, args);
	}

}
