package com.training.trainingapp.DTO;

import lombok.Data;

@Data
public class LoginDTO {
    private String username;
    private String password;
}
